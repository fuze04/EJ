/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pract2;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class HttpSessionServlet extends HttpServlet
{ 
 private int counter;
 public void doGet(HttpServletRequest request, HttpServletResponse response) throws 
ServletException, IOException
 { 
 response.setContentType("text/html");
 PrintWriter out = response.getWriter();
 HttpSession session=request.getSession(true); 
 if(session.isNew())
 { 
 out.print("This is the first time you are visiting this page");
 ++counter;
 }
 else
 {
     synchronized(HttpSessionServlet.this)
 { 
 if(counter==10)
 { session.invalidate();
 counter=0;
 request.getSession(false);
 } 
 else
 out.print("You have visited this page "+(++counter)+ " times");
 } 
 }
 } 
}

 