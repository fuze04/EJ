/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.interestcalculator;

import javax.ejb.Stateless;

/**
 *
 * @author admin
 */
@Stateless
public class InterestCalculator {

    public double calculateSimpleInterest(double principal, double rate, double years) {
        // Simple Interest Formula: SI = P * R * T / 100
        return (principal * rate * years) / 100.0;
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    public double calculateCompoundInterest(double principal, double rate, double years) {
        // Compound Interest Formula: A = P * (1 + R/n)^(nt) - P
        // where A is the amount, P is the principal, R is the annual interest rate,
        // n is the number of times that interest is compounded per unit 't', and t is the time in years.
        int n = 12; // assuming interest is compounded monthly
        double amount = principal * Math.pow(1 + rate / (n * 100), n * years);
        return amount - principal;
    }
}
