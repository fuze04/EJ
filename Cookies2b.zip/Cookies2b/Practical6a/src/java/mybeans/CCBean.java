/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mybeans;

import javax.ejb.Stateless;

/**
 *
 * @author USER
 */
@Stateless
public class CCBean implements CCBeanLocal {
public double r2Dollar(double r)
{
 return r/82.36; 
}
public double d2Rupees(double d)
{
 return d*82.36; 
} 
}
