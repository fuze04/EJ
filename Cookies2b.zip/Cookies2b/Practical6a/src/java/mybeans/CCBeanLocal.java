/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mybeans;

import javax.ejb.Local;
//import javax.ejb.Stateless;
/**
 *
 * @author USER
 */
@Local
public interface CCBeanLocal {
public double r2Dollar(double r);
public double d2Rupees(double d); 
}
