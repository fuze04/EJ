import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class store extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String productName = request.getParameter("productName");
        String productPrice = request.getParameter("productPrice");
        String quantity = request.getParameter("quantity");

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/inventorydb", "root", "123456");

            PreparedStatement ps = con.prepareStatement("INSERT INTO inventory (productName, productPrice, quantity) VALUES (?, ?, ?)");
            ps.setString(1, productName);
            ps.setString(2, productPrice);
            ps.setString(3, quantity);

            int i = ps.executeUpdate();
            
                PrintWriter out = response.getWriter();
                out.println("<html><body><b>Successfully Inserted" + "</b></body></html>");
        

        } catch (Exception e2) {
            System.out.println(e2);
        }
    }
}
