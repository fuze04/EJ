import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/BiodataServlet"})
public class BiodataServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Connection con = null;
        PreparedStatement ps = null;
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String name = request.getParameter("name");
        String age = request.getParameter("age");
        String address = request.getParameter("add");
        String hobbies = request.getParameter("hobby");
        String gender = request.getParameter("sex");
        String qualification = request.getParameter("qualify");
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bio", "root", "123456");
            out.println("Connection done successfully...");

            // Make sure the table name is correct (here, assuming it is "user")
            ps = con.prepareStatement("insert into details (Name, Age, Address, Hobbies, Gender, Qualification) values (?,?,?,?,?,?)");
            ps.setString(1, name);
            ps.setString(2, age);
            ps.setString(3, address);
            ps.setString(4, hobbies);
            ps.setString(5, gender);
            ps.setString(6, qualification);
            ps.execute();

            out.print("Data inserted successfully!!!!");
        } catch (Exception e) {
            out.println(e);
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                out.println(e);
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
