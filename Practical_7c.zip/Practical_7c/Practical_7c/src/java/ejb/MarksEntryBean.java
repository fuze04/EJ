/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;
import java.sql.*;
import javax.ejb.Stateful;

/**
 *
 * @author hina_
 */
@Stateful
public class MarksEntryBean {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    String sname;
int m1,m2,m3;
Connection con=null;
Statement st=null;
String query="";
public void addMarks(String sname,int m1,int m2,int m3)
{
 try
 {
 Class.forName("com.mysql.jdbc.Driver");
 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/marksdb", "root","123456");
 st=con.createStatement();
 query="insert into marks (sname,marks1,marks2,marks3) values ('"+sname+"','"+m1+"','"+m2+"','"+m3+"')";
 st.executeUpdate(query);
 System.out.print("Marks entered sucessfully!!"); 
 }
 catch(Exception e){System.out.println(e);}
}
}
